{ lib, coreModules, ... }: nodeName: nodeName
