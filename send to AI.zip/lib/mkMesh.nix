{
  lib,
  coreModules,
  ...
}:
meshConfig:
let
  eval = lib.evalModules {
    modules = coreModules ++ [
      { nixmesh = meshConfig; }
    ];
  };
in
lib.mapAttrs (name: nodeConfig: {
  name = lib.nixosSystem {
    system = "x86_64-linux";
    modules = [ ];
  };
}) meshConfig.cluster.nodes
