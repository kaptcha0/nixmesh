{
  description = "A very basic flake";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=nixos-unstable";

    nixmesh = {
      url = "path:../../";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  };

  outputs =
    {
      nixmesh,
      ...
    }:
    {
      modules = [ nixmesh.modules.default ];

      nixosModules = nixmesh.lib.mkMesh {
        cluster = {
          volumes = import ./volumes.nix { inherit nixmesh; };
          nodes = import ./nodes.nix { inherit nixmesh; };
          jobs = import ./jobs.nix { inherit nixmesh; };
          ingress = import ./ingress.nix { inherit nixmesh; };
        };

        secrets = {
          loadSecrets =
            { ... }:
            {
              sops.defaultSopsFile = ./secrets.sops.yaml;
              sops.secrets.pgsql-pass = { };
              sops.secrets.smb-password = { };
            };

          fetchSecret = name: { config, ... }: config.sops.secrets.${name}.path;
        };
      };
    };
}
